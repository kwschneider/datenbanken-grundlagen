DELETE FROM Artikel
WHERE ArtikelID = 5;
