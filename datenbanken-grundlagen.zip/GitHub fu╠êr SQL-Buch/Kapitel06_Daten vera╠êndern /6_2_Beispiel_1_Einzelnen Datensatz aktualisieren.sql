UPDATE Artikel
SET Preis = 55.00
WHERE ArtikelID = 10;
