INSERT INTO Kunden (Vorname, Nachname, Email)
VALUES ('Lisa', 'Müller', 'lisa.m@example.com');
