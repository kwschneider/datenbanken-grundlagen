DELETE FROM Artikel;
-- Achtung! Jetzt sind alle Artikel aus der Tabelle verschwunden!
