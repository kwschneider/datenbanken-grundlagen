SELECT Name, Preis
FROM Artikel
ORDER BY Preis DESC;
