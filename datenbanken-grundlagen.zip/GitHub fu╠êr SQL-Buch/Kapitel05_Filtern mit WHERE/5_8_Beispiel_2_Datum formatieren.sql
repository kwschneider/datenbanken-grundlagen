SELECT STRFTIME('%Y-%m', 'now'); -- Ergebnis: 2025-11
